import React, { Component } from 'react';
import { AppRegistry, Text, View, StyleSheet, Image, TextInput, ImageBackground, TouchableHighlight, Alert, Dimensions } from 'react-native';
import Constants from 'expo-constants';

let deviceHeight = Dimensions.get('window').height;
let deviceWidth = Dimensions.get('window').width;

export default class App extends Component {
    
    state = {
        menu: "block",
        usdConvert: "none",
        tipCalculator: "none",
        
        originalBill: 0,
        billWithTip: 0,
        tip: 0,
        newTip: 0,
        
        usdInput: 0,
        convertedValue: 0,
        symbol: " ",
    }
    
    convertFromUSD = (currency) => {
        if (currency == 'euro') {
            this.setState({ 
                convertedValue: this.state.usdInput * 1.02,
                symbol: "€",
            })
        } else if (currency == 'rupee') {
            this.setState({ 
                convertedValue: this.state.usdInput * 82.13,
                symbol: "₹",
            })
        } else if (currency == 'franc') {
            this.setState({ 
                convertedValue: this.state.usdInput * 0.9983,
                symbol: "CHF",
            })
        } else if (currency == 'yen') {
            this.setState({ 
                convertedValue: this.state.usdInput * 147.16,
                symbol: "¥",
            })
        }
    }
    
    menuPress=()=> this.setState(state => ({
        menu: "block",
        usdConvert: "none",
        tipCalculator: "none",
    }));
    usdPress=()=> this.setState(state => ({
        menu: "none",
        usdConvert: "block",
        tipCalculator: "none",
    }));
    
    tipPress=()=> this.setState(state => ({
        menu: "none",
        usdConvert: "none",
        tipCalculator: "block",
    }));
    
    p10 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.10),
            newTip: (this.state.tip + 10),
        })
    }
    p15 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.15),
            newTip: (this.state.tip + 15),
        })
    }
    p20 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.20),
            newTip: (this.state.tip + 20),
        })
    }
    p25 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.25),
            newTip: (this.state.tip + 25),
        })
    }
    p30 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.30),
            newTip: (this.state.tip + 30),
        })
    }
    p35 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.35),
            newTip: (this.state.tip + 35),
        })
    }
    
    render() {
        return (
            <View style={styles.container}>
                <View style = {{display: this.state.menu}}>
                    <View style = {{textAlign: "center", alignItems: "center", justifyContent: "center"}}>
                        <Text style = {{fontSize: 30, fontWeight: "bold", }}>
                            Currency Converter and Tip Calculator
                        </Text>
                        <TouchableHighlight style = {styles.menuButton}
                            onPress={this.usdPress}
                        >
                            <Text style = {styles.textInput}>
                                USD
                            </Text>
                        </TouchableHighlight>
                        <TouchableHighlight style = {styles.menuButton}
                            onPress={this.tipPress}
                        >
                            <Text style = {styles.textInput}>
                                Tip Calculator
                            </Text>
                        </TouchableHighlight>
                    </View>
                </View>
                
                {/*US DOLLAR*/}
                <View style = {{display: this.state.usdConvert}}>
                    <View style = {styles.contentContainer}>
                        <View style = {styles.top}>
                            <Text style = {{fontSize: 40, fontWeight: "bold"}}>
                                Currency Converter
                            </Text>
                        </View>
                        
                        <View style = {styles.middle}>
                            <Text style = {{fontSize: 25, fontWeight: "bold"}}>
                                Insert USD Value
                            </Text>
                            <TextInput style={styles.input}
                                onChangeText={(usdInput) => this.setState({usdInput})}
                                value={this.state.usdInput}
                            />
                            <View style = {styles.buttonContainer}>
                                <TouchableHighlight style = {styles.button}
                                    onPress={() => this.convertFromUSD('euro')}
                                >
                                    <Text style = {styles.textInput}>
                                        Euro
                                    </Text>
                                </TouchableHighlight>
                                
                                <TouchableHighlight style = {styles.button}
                                    onPress={() => this.convertFromUSD('rupee')}
                                >
                                    <Text style = {styles.textInput}>
                                        Rupee
                                    </Text>
                                </TouchableHighlight>
                            </View>
                            <View style = {styles.buttonContainer}>
                                <TouchableHighlight style = {styles.button}
                                    onPress={() => this.convertFromUSD('franc')}
                                >
                                    <Text style = {styles.textInput}>
                                        Franc
                                    </Text>
                                </TouchableHighlight>
                                <TouchableHighlight style = {styles.button}
                                    onPress={() => this.convertFromUSD('yen')}
                                >
                                    <Text style = {styles.textInput}>
                                        Yen
                                    </Text>
                                </TouchableHighlight>
                            </View>
                        </View>
                        
                        <View style = {styles.bottom}>
                            <Text style = {{fontSize: 25, fontWeight: "bold", color: "purple"}}>
                                Converted Value
                            </Text>
                            <Text style = {{fontSize: 40, fontWeight: "bold"}}>
                                {this.state.symbol} {this.state.convertedValue.toFixed(2)}
                            </Text>
                        </View>
                        
                        <View style = {styles.navbarContainer}>
                            <TouchableHighlight style = {{height:2*(deviceHeight/15), alignItems: "center"}}
                                onPress={this.menuPress}
                            >
                                <Text style = {{fontSize: 20, fontWeight: "bold", margin: 10}}>
                                    Go back to Menu
                                </Text>
                            </TouchableHighlight>
                        </View>
                    </View>
                </View>
                
                <View style = {{display: this.state.tipCalculator}}>
                    <View style = {styles.contentContainer}>
                        <View style = {styles.container1}>
                            <View style={styles.titleContainer1}>
                                <ImageBackground
                                    style={{height: deviceHeight/6, width: deviceWidth}}
                                    source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFZmBR6nfgSVp6GCYPDTwYC-BbwPqkPiB4m2Q7QCtb8tJX9RlGS-_kfkbdYzGb8gXy2JY&usqp=CAU' }}
                                >
                                    <View style={styles.titleContainer1}>
                                        <Text style={styles.title1}>
                                            Mehers Tip Calculator
                                        </Text>
                                    </View>
                                </ImageBackground>
                                <Text style={{fontSize: 25, color: "white", textAlign: "center", margin: 5}}>
                                    Input Original Bill
                                </Text>
                                
                                <TextInput style={{fontSize: 30, color: "#b83c70", textAlign: "center"}}
                                    onChangeText={(originalBill) => this.setState({originalBill})}
                                    value={this.state.originalBill}
                                />
                            
                                <View style={styles.buttonContainer1}>
                                    <TouchableHighlight style={styles.button1}
                                        onPress = {this.p10}
                                    >
                                        <Text style={styles.buttonText1}>
                                            10%
                                        </Text>
                                    </TouchableHighlight>
                                    <TouchableHighlight style={styles.button1}
                                        onPress = {this.p15}
                                    >
                                        <Text style={styles.buttonText1}>
                                            15%
                                        </Text>
                                    </TouchableHighlight>
                                </View>
                                
                                <View style={styles.buttonContainer1}>
                                    <TouchableHighlight style={styles.button1}
                                        onPress = {this.p20}
                                    >
                                        <Text style={styles.buttonText1}>
                                            20%
                                        </Text>
                                    </TouchableHighlight>
                                    <TouchableHighlight style={styles.button1}
                                        onPress = {this.p25}
                                    >
                                        <Text style={styles.buttonText1}>
                                            25%
                                        </Text>
                                    </TouchableHighlight>
                                </View>
                                
                                <View style={styles.buttonContainer1}>
                                    <TouchableHighlight style={styles.button1}
                                        onPress = {this.p30}
                                    >
                                        <Text style={styles.buttonText1}>
                                            30%
                                        </Text>
                                    </TouchableHighlight>
                                    <TouchableHighlight style={styles.button1}
                                        onPress = {this.p35}
                                    >
                                        <Text style={styles.buttonText1}>
                                            35%
                                        </Text>
                                    </TouchableHighlight>
                                </View>
                                <Text style={styles.paragraph1}>
                                    {this.state.originalBill} with {this.state.newTip} % tip:
                                </Text>
                                <Text style={styles.paragraph1}>
                                    $ {this.state.billWithTip.toFixed(2)}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
                
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        height: deviceHeight,
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
    },
    contentContainer: {
        height: deviceHeight,
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
    },
    top: {
        height: deviceHeight/4,
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: "center",
        backgroundColor: '#CBC3E3',
    },
    middle: {
        height: deviceHeight/2,
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#ffcccb',
        margin: 5,
    },
    bottom: {
        height: deviceHeight/6,
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'lightblue',
        marginBottom: 5,
    },
    navbarContainer: {
        height: 2*(deviceHeight/15),
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: "center",
        backgroundColor: 'darkBlue',
        color: "white",
    },
    menuButton:{
        height: deviceHeight/8,
        width: 5*(deviceWidth/6),
        backgroundColor: 'lightgreen',
        textAlign: "center",
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
        fontSize: 25,
    },
    input:{
        height: deviceHeight/8,
        width: 4*(deviceWidth/6),
        borderWidth: 2,
        borderColor: "black",
        textAlign: "center",
        justifyContent: 'center',
        fontSize: 25,
        margin: 10,
    },
    textInput: {
        margin: 5,
        fontSize: 25,
    },
    buttonContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: "row",
    },
    button:{
        height: deviceHeight/10,
        width: 2*(deviceWidth/6),
        backgroundColor: 'white',
        borderWidth: 2,
        borderColor: "black",
        textAlign: "center",
        alignItems: 'center',
        justifyContent: 'center',
        margin: 5,
        fontSize: 25,
    },
    
    
    container1: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: "center",
        backgroundColor: '#4db3e4',
    },
    titleContainer1: {
        height: deviceHeight/6,
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: "center",
    },
    title1: {
        color: 'black',
        fontSize: 35,
        textAlign: 'center',
        fontWeight: 'bold',
        marginBottom: 10,
    },
    paragraph1: {
        color: '#b83c70',
        fontSize: 30,
        textAlign: 'center',
        marginTop: 10,
    },
    buttonContainer1: {
        flexDirection: 'row',
        width: deviceWidth,
    },
    button1: {
        height: 50,
        width: 100,
        backgroundColor: '#fda649',
        borderColor: 'white',
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
        marginLeft: 30,
    },
    buttonText1: {
        color: 'white',
        fontSize: 25,
        textAlign: 'center',
    },
});